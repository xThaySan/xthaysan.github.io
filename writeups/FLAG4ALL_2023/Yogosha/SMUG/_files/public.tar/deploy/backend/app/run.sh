while :; do uvicorn main:app --host 0.0.0.0 --reload; done
