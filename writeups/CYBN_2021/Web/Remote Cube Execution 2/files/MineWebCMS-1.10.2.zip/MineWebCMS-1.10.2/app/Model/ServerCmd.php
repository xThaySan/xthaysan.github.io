<?php
class ServerCmd extends AppModel {
}